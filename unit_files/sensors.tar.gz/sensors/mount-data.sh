#!/bin/sh

sudo mount /dev/mmcblk0p4 /mnt/other

