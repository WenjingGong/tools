#! /bin/bash

i2cset -y 1 0x54 0x08 0x35

/usr/lib/leeonl/sensors/setup


