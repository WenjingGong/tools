#!/bin/sh

cat /sys/class/gpio/gpio17/value
