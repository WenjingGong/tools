#!/bin/sh

umount /dev/mmcblk0p4
